from django.contrib import admin
from .models import Contact,Blogposts
admin.site.register(Contact)
admin.site.register(Blogposts)