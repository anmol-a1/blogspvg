from django.shortcuts import redirect, render,HttpResponse
from . models import Contact,Blogposts
from django.contrib.auth.models import User 
from django.contrib.auth import authenticate,login,logout
import os

from django.contrib import messages
def index(request):
    # current_user = request.user
    # print(current_user.first_name)
    blogs=Blogposts.objects.all()
    context={'blogs':blogs}

    return render(request,"home/index.html",context)
def contact(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        phone_no=request.POST['phone_no']
        issue=request.POST['issue']
        if len(name)>10 and len(issue)>10:
            cont=Contact(name=name,email=email,phone_no=phone_no,issue=issue)
            cont.save()
            messages.success(request,"Success")
    return render(request,"home/contact.html")
def logindof(request):
    if request.method=="POST":
        loginusername=request.POST['username1']
        loginpassword=request.POST['password1']
        user=authenticate(username=loginusername,password=loginpassword)
        if user is not None:
            login(request, user)
            return redirect("/")
    return redirect("/loginsignup")
    
        
def signupdof(request):
    if request.method=="POST":
        username=request.POST['username']
        email=request.POST['email']
        pass1=request.POST['password']
        fname=request.POST['firstname']
        lname=request.POST['lastname']
        myuser=User.objects.create_user(username,email,pass1)
        myuser.first_name=fname
        myuser.last_name=lname
        myuser.save()
    else:
        return HttpResponse("404 page not found")
    return redirect("/loginsignup")
def logoutdof(request):
    logout(request)
    return redirect("/")
print(User)
def loginsignup(request):
    return render(request,"home/loginsignup.html")
def about(request):
    return render(request,"home/about.html")
def myblogs(request):
    return render(request,"home/myblogs.html")
def trending(request):
    return render(request,"home/trending.html")

# Create your views here.
